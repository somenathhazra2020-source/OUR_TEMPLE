Hazra Bari Dual Temple - 135.py Panchang FIX

Panchang source:
- Durgapur Day Panchang for Tithi, Nakshatra, Yoga, Karana and Paksha.
- Durgapur astronomical Sunrise/Moonrise monthly table for the actual-date Moonrise/Moonset.

Important:
- No Swiss Ephemeris, pyswisseph, pysweph or ephem dependency is used.
- Moonrise/Moonset shown in the Panchang cards are the astronomical values for the actual calendar date.
- The app remains IST / Durgapur localized.
