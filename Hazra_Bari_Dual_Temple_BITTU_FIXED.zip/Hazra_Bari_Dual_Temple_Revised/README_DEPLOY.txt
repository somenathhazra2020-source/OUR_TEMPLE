HAZRA BARI VIRTUAL DUAL TEMPLE — UPDATED PACKAGE

Main Streamlit entry file: BITTU.PY

Deploy with: streamlit run BITTU.PY

Included fixes:
- Durgapur astronomical times use Sunrise-Sunset.org API v2, parsed as ISO-8601 and converted to Asia/Kolkata (IST).
- Sunrise/sunset fall back to Astral calculations if the API is unreachable; moonrise/moonset remain unavailable rather than guessed.
- Sun/moon timings remain visible even if Navamsha Panchang credentials are missing. Tithi/Nakshatra/Yoga/Paksha still require a valid Navamsha API key.
- A clearly visible, always-lit virtual Akhand Diya status appears on both Maa Durga and Mahadev Shiva Darshan cards and in Aarti.
- The Shiva deity image is bundled as mahadev_shiva.png.

Streamlit Secrets for live Panchang details:
PANCHANG_API_URL = "https://api.navamsha.in/api/v1/panchang/full"
PANCHANG_API_KEY = "your-valid-Navamsha-key"

Astronomical data attribution is displayed in the app: https://sunrise-sunset.org/api
